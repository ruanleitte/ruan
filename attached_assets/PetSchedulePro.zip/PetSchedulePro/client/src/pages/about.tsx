import { Card, CardContent } from "@/components/ui/card";

export default function About() {
  return (
    <div className="container py-16 max-w-5xl mx-auto">
      <div className="text-center mb-12">
        <h1 className="text-3xl font-bold mb-4">SOBRE <span className="text-primary">MIM</span></h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Conheça um pouco mais sobre minha jornada profissional, habilidades e objetivos.
        </p>
      </div>
      
      {/* About content */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
        {/* Image */}
        <div className="aspect-square relative rounded-xl overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" 
            alt="Ruan Jasiel" 
            className="w-full h-full object-cover"
          />
        </div>
        
        {/* Text Content */}
        <div className="flex flex-col justify-center">
          <h2 className="text-2xl font-bold mb-6">
            Analista de Planejamento e Desenvolvedor Web
          </h2>
          
          <p className="text-muted-foreground mb-4">
            Sou um profissional com experiência em planejamento estratégico e logística, 
            atualmente desenvolvendo competências em desenvolvimento web e programação. Minha 
            formação em Gestão de Logística me deu uma sólida base em processos e 
            otimização, enquanto meu interesse por tecnologia me levou a explorar o 
            desenvolvimento de soluções digitais.
          </p>
          
          <p className="text-muted-foreground mb-6">
            Minha experiência em empresas como Mills, Stone e GOL Linhas Aéreas me 
            proporcionou habilidades valiosas em gestão de equipes, resolução de problemas 
            e atendimento ao cliente. Agora, busco combinar essas competências com minhas 
            habilidades técnicas em desenvolvimento web para criar soluções eficientes e 
            intuitivas.
          </p>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h3 className="font-bold mb-2">Data de Nascimento</h3>
              <p className="text-muted-foreground">12 de Maio, 1990</p>
            </div>
            <div>
              <h3 className="font-bold mb-2">Nacionalidade</h3>
              <p className="text-muted-foreground">Brasileiro</p>
            </div>
            <div>
              <h3 className="font-bold mb-2">Localização</h3>
              <p className="text-muted-foreground">Salvador, Bahia</p>
            </div>
            <div>
              <h3 className="font-bold mb-2">Idiomas</h3>
              <p className="text-muted-foreground">Português, Inglês, Espanhol</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Services Section */}
      <div className="mb-16">
        <h2 className="text-2xl font-bold mb-8 text-center">
          Serviços que <span className="text-primary">Ofereço</span>
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6 text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-primary/10 rounded-full flex items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary"><path d="M12 19l7-7 3 3-7 7-3-3z"></path><path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z"></path><path d="M2 2l7.586 7.586"></path><circle cx="11" cy="11" r="2"></circle></svg>
              </div>
              <h3 className="text-xl font-bold mb-2">Web Design</h3>
              <p className="text-muted-foreground">
                Criação de interfaces modernas, responsivas e centradas no usuário, combinando estética e usabilidade.
              </p>
            </CardContent>
          </Card>
          
          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6 text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-primary/10 rounded-full flex items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary"><polyline points="16 18 22 12 16 6"></polyline><polyline points="8 6 2 12 8 18"></polyline></svg>
              </div>
              <h3 className="text-xl font-bold mb-2">Desenvolvimento Web</h3>
              <p className="text-muted-foreground">
                Construção de sites e aplicações web com as tecnologias mais modernas para garantir desempenho e escalabilidade.
              </p>
            </CardContent>
          </Card>
          
          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6 text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-primary/10 rounded-full flex items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"></path></svg>
              </div>
              <h3 className="text-xl font-bold mb-2">Consultoria em Processos</h3>
              <p className="text-muted-foreground">
                Otimização de processos organizacionais e logísticos, aplicando metodologias ágeis e ferramentas de gestão.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
      
      {/* Testimonials */}
      <div>
        <h2 className="text-2xl font-bold mb-8 text-center">
          O que <span className="text-primary">Dizem</span> Sobre Mim
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 rounded-full overflow-hidden">
                  <img 
                    src="https://images.unsplash.com/photo-1564564321837-a57b7070ac4f?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80" 
                    alt="Cliente" 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <h3 className="font-bold">Alexandre Costa</h3>
                  <p className="text-muted-foreground text-sm">Gerente de Projetos, Mills</p>
                </div>
              </div>
              <p className="text-muted-foreground">"Ruan é um profissional dedicado e competente. Sua capacidade de resolução de problemas e atenção aos detalhes foram essenciais para o sucesso dos projetos que gerenciamos juntos."</p>
            </CardContent>
          </Card>
          
          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 rounded-full overflow-hidden">
                  <img 
                    src="https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80" 
                    alt="Cliente" 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <h3 className="font-bold">Fernanda Lima</h3>
                  <p className="text-muted-foreground text-sm">Coordenadora, GOL Linhas Aéreas</p>
                </div>
              </div>
              <p className="text-muted-foreground">"Um colaborador excepcional, sempre disposto a ir além para entregar resultados. Sua abordagem analítica e visão estratégica foram extremamente valiosas para nossa equipe."</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
