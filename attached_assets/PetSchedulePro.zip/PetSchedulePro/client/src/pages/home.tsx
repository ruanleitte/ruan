import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import { useEffect, useState, useRef } from "react";

export default function Home() {
  const [typedText, setTypedText] = useState("");
  const [currentPhraseIndex, setCurrentPhraseIndex] = useState(0);
  const phrases = ["DESENVOLVEDOR WEB", "UI/UX", "ANALISTA DE PLANEJAMENTO"];
  const typingRef = useRef(null);
  
  useEffect(() => {
    const typeText = async () => {
      while (true) {
        const currentPhrase = phrases[currentPhraseIndex];
        
        // Type current phrase (slower typing speed - 150ms)
        for (let i = 0; i <= currentPhrase.length; i++) {
          setTypedText(currentPhrase.substring(0, i));
          await new Promise(resolve => setTimeout(resolve, 150));
        }
        
        // Longer pause at the end of the phrase (3 seconds)
        await new Promise(resolve => setTimeout(resolve, 3000));
        
        // Delete the phrase (slower deletion - 100ms)
        for (let i = currentPhrase.length; i >= 0; i--) {
          setTypedText(currentPhrase.substring(0, i));
          await new Promise(resolve => setTimeout(resolve, 100));
        }
        
        // Move to next phrase
        setCurrentPhraseIndex((currentPhraseIndex + 1) % phrases.length);
        
        // Longer pause before typing next phrase (1 second)
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    };
    
    typeText();
    
    return () => {
      // Cleanup if needed
    };
  }, [currentPhraseIndex]);

  return (
    <div className="w-full min-h-screen flex items-center justify-center p-4 py-10 md:py-0 bg-background overflow-hidden">
      <div className="w-full max-w-6xl flex items-center justify-center">
        <div className="flex flex-col md:flex-row items-center justify-center gap-8">
          {/* Profile image with innovative frame effect */}
          <motion.div 
            className="w-full max-w-md relative"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            {/* Decorated frame with rotating borders */}
            <div className="relative w-full h-full pt-8 pl-8">
              {/* Rotating top-left corner */}
              <div className="absolute top-0 left-0 w-16 h-16 z-10">
                <div className="absolute top-0 left-0 w-full h-2 bg-primary rounded-tl-md" style={{ transform: 'rotate(0deg)' }}></div>
                <div className="absolute top-0 left-0 h-full w-2 bg-primary rounded-tl-md" style={{ transform: 'rotate(0deg)' }}></div>
              </div>
              
              {/* Gradient background */}
              <div className="relative overflow-hidden rounded-lg shadow-xl bg-gradient-to-br from-primary/80 to-purple-500/80 p-2">
                {/* Image container with mask */}
                <div className="overflow-hidden rounded-lg relative">
                  <img 
                    src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=774&q=80" 
                    alt="Ruan Jasiel"
                    className="w-full h-auto object-cover aspect-[1/1.2] rounded-lg transition-all duration-500 hover:scale-105" 
                  />
                  
                  {/* Overlay on hover */}
                  <div className="absolute inset-0 bg-gradient-to-t from-primary/60 to-transparent opacity-0 hover:opacity-100 transition-opacity duration-300"></div>
                </div>
              </div>
              
              {/* Rotating bottom-right corner */}
              <div className="absolute bottom-0 right-0 w-16 h-16 z-10">
                <div className="absolute bottom-0 right-0 w-full h-2 bg-primary rounded-br-md" style={{ transform: 'rotate(0deg)' }}></div>
                <div className="absolute bottom-0 right-0 h-full w-2 bg-primary rounded-br-md" style={{ transform: 'rotate(0deg)' }}></div>
              </div>
              
              {/* Background decorative elements */}
              <div className="absolute -bottom-3 -right-3 w-24 h-24 bg-primary/10 rounded-full z-[-1]"></div>
              <div className="absolute -top-3 -left-3 w-16 h-16 bg-purple-500/10 rounded-full z-[-1]"></div>
            </div>
          </motion.div>
          
          {/* Content */}
          <motion.div 
            className="w-full max-w-md space-y-5 p-4 md:p-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <div className="inline-block bg-primary text-primary-foreground px-4 py-1 rounded-full">
              <span className="font-medium">HELLO</span>
            </div>
            
            <h1 className="text-3xl md:text-5xl font-bold">
              I'M <span className="bg-clip-text text-transparent bg-gradient-to-r from-primary via-purple-500 to-primary bg-gradient-animated">RUAN JASIEL</span>
            </h1>
            
            <h2 className="text-xl md:text-2xl font-semibold flex items-center">
              I DO <span className="ml-2 min-h-[30px] inline-block border-r-2 border-primary pr-1">{typedText}</span>
            </h2>
            
            <p className="text-muted-foreground text-sm md:text-base">
              Com mais de 5 anos de experiência profissional. Formado em Gestão Logística,
              aprimorei minhas habilidades através de trabalhos comerciais e freelance. 
              Minhas competências incluem HTML, CSS, JavaScript, React e frameworks web modernos.
            </p>
            
            <div className="pt-4">
              <Button asChild size="lg" className="btn-hover">
                <Link href="/portfolio">
                  <span className="flex items-center gap-2 uppercase font-semibold">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path></svg>
                    PORTFOLIO
                  </span>
                </Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
